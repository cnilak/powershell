SELECT B.ApplicationName, B.ServerName, B.VersionDescription , B.WindowsVersion, B.Environment ,A.ReplicatedServerName, A.DatabaseName, A.DatabaseSize, A.Listener, A.RecoveryModel, A.ReplicationType
  FROM [DBAdmin].[dbo].[SqlDatabase] A, SqlServer B
WHERE DatabaseName like '%<DBName>%'
and B.ServerID = A.ServerID
