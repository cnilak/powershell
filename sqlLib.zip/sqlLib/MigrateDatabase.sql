﻿##############################################################
# Migrate new set of databases to AVG
##############################################################
$dbSourceServer = 'SVR-SNDBX08'
$dbTargetPrimaryServer = 'SWVDCRVDBADB01'
$dbTargetSecondaryServer = 'SWWDCRVDBADB01'
$dbTargetAVGName = 'DBADBAG'
$dbList = @(
    'ChitaTest3'
)

#Step1
$dbList | ForEach-Object {Copy-SQLDatabase -dbSourceServer $dbSourceServer -dbTargetServer $dbTargetPrimaryServer -dbName $_}


#Step2
$dbList | ForEach-Object {
    Invoke-Sqlcmd -ServerInstance $dbTargetPrimaryServer -InputFile \\SVR-SNDBX08\DBAScripts\Chita\sqlLib\GetOrphanLoginInfo.sql -Database $_  -Verbose
}

#check orphan logins
$dbList | ForEach-Object {
    Invoke-Sqlcmd -ServerInstance $dbTargetPrimaryServer -InputFile \\SVR-SNDBX08\DBAScripts\Chita\sqlLib\GetOrphanLoginInfo.sql -Database $_  -Verbose | ForEach-Object {
        $login = $_.user_name
        $query = "exec sp_help_revlogin '$login'"
        Invoke-Sqlcmd -ServerInstance $dbSourceServer -Query $query
    }
} 

#Step3
$dbList | ForEach-Object {New-DatabaseToAVG -dbPrimaryServer $dbTargetPrimaryServer -dbSecondaryServer $dbTargetSecondaryServer -avgName $dbTargetAVGName -dbName $_}
##############################################################
