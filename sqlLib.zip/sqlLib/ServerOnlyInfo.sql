SELECT distinct [ServerName]
      ,[VersionDescription]
      ,[ProductLevel] as SP
      ,[Edition]
      ,[isCLustered]
      ,[Environment] as ENV
      ,[NumberofCores] as Cores
      ,[PhysicalMemory] as Memory
	   ,[ApplicationName]
      ,[BusinessGroup]
      ,[BusinessContact]
      ,A.[Description]
	  ,A.Collation
  FROM [DBAdmin].[dbo].[SqlServer] A  
  Order by Environment, ServerName, ApplicationName,VersionDescription