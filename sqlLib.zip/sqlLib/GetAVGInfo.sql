select dns_name as Listner, port as ListnerPort, ip_configuration_string_from_cluster as ListnerIP
, name as AVGName,  replica_server_name as Replicas, endpoint_url as EndpointURL, availability_mode_desc as AvailabilityMode, failover_mode_desc as FailoverMode
from 
sys.availability_replicas, sys.availability_group_listeners, sys.availability_groups