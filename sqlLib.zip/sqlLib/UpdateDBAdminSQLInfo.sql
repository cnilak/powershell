--*******************Fill out and execute on swhadcrvsqldba instance ********************

USE [DBAdmin]
GO

DECLARE @Description nvarchar(500), @ApplicationName nvarchar(200), 
@BusinessGroup nvarchar(255), @LicenseId nchar(1), @BusinessContact nvarchar(255), @NumLicenses nchar(3),
@Environment nvarchar(25)

SELECT @Description = '<Description>', 
@ApplicationName = '<ApplicationName>', 
@BusinessGroup  = '<BusinessGroup>', 
@BusinessContact  = '<BusinessContact>',
@Environment = '<Environment>',
@LicenseId = '<LicenseId>', 
@NumLicenses = '<NumLicenses>'

UPDATE [DBAdmin].[dbo].[SqlServer]

SET [Description] = @Description
 ,[ApplicationName] = @ApplicationName
 ,[BusinessGroup] = @BusinessGroup
 ,[BusinessContact] = @BusinessContact
 ,[LicenseId] = @LicenseId --(1 = Enterprise Edition Server, 2 = Standard Edition Server, 3 = Enterprise Edition Processor, 4 = Standard Edition Processor, 5 = Client Access Licenses)
 ,[NumLicenses] = @NumLicenses --Complete if CAL license is used
 ,[Environment] = @Environment
WHERE ServerName = '<DBSERVER>'
GO
