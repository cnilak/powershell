SELECT   MAX(login_time) AS [Last Login Time], loginame [Login], DB_NAME(database_id) [Database], @@SERVERNAME [ServerName]
FROM sys.databases d
LEFT JOIN sysprocesses sp ON d.database_id = sp.dbid
WHERE database_id NOT BETWEEN 0
  AND 4
 AND loginame IS NOT NULL
 GROUP BY loginame, DB_NAME(database_id)
order by DB_NAME(database_id), Login,[Last Login Time]