USE [msdb]
GO

DECLARE @RC int

-- TODO: Set parameter values here.

EXECUTE @RC = [dbo].[RestoreTSMServerAdvHADR] 
   <SourceNodeName>,<SourceTSMServerName>,<DestServer>,<SourceDBName>,<TargetDBName>,<TargetMDFLocation>,<TargetLDFLocation>,<BkType>
   ,<Recovery>,<Object>,<TargetFileLocations>,<Isalwayson>,<userid>


