select session_id, start_time, command, database_id, percent_complete, estimated_completion_time, DB_NAME(database_id) databasename,
blocking_session_id, wait_type,last_wait_type, 
dest.text AS sqlstatement--, sql_handle
FROM sys.dm_exec_requests AS deqs
CROSS APPLY sys.dm_exec_sql_text(deqs.sql_handle) AS dest 