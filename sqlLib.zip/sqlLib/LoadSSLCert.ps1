﻿Install-SqlTDECertificate -dbCertServer SWVDCRVKFXDB02  -certPlainPwd (Get-SqlPlainPassword -pwdFile TDE_PROD)


if(get-module -Name SqlUtility) {
    Remove-Module -Name SqlUtility
} 
import-module \\SVR-SNDBX08\DBAScripts\Chita\Modules\SqlUtility.psm1  -Verbose
$dbCertServer = 'SWVDCRVSQLDB14'

$certPlainPwd = Get-SqlPlainPassword -pwdFile TDE_PROD

$certSecPwd = ConvertTo-SecureString ($certPlainPwd) -AsPlainText -Force -Verbose

#enable cred SSP for double hop
Enable-WSManCredSSP -Role Client -DelegateComputer SWVDCDVV360DV03 -Verbose

<#
Enable-WSManCredSSP -Role Client -DelegateComputer "$($dbCertServer).nfcu.net" -Verbose

Invoke-Command -ComputerName $dbCertServer -ScriptBlock {
    Enable-PSRemoting -Force
    Enable-WSManCredSSP -Role Server -Verbose
    Set-Item wsman:\localhost\client\trustedhosts * -Verbose
    Restart-Service WinRM -Verbose
} -Verbose
#>

#Get-WSManCredSSP
#Step0: Check if the certificate already exist on the server 
#Enter-PSSession -ComputerName $dbCertServer -Authentication Credssp -Credential (Get-Credential) -Verbose 
$dbCertificate = (Get-ChildItem Cert:\LocalMachine\My -Verbose) 

if ($dbCertificate -eq $null) {
    Write-Host No certificate is installed on the server: $dbCertServer -ForegroundColor Yellow
}
else {
    $oldCert = $dbCertificate[0]
    $dbCertificate = $null
}
#Step: Check if the pfx file exist on the DBA box for that server.
$pfxFile = ''
$certFiles = ''
Get-ChildItem \\SWVDCLVSNDBDB01\j$\software\SSLCert\ | ? {$_.Name -match $dbCertServer} | % {
    $pfxFile = $_.GetFiles() | ? {$_.Name -match "$($dbCertServer).nfcu.net.pfx"}
    $certFiles = $_.GetFiles() | ? {$_.Name -match ".cer"}
}
#Step: Run the PVK converter to create cert file and pvk file.
if($certFiles -eq $null) {
  Invoke-Command -ComputerName  SWVDCLVSNDBDB01 -ScriptBlock {  
    Invoke-Expression "& `"J:\Program Files (x86)\Microsoft\PVKConverter\PVKConverter.exe`" -i j:\software\SSLCert\$Using:dbCertServer\$Using:dbCertServer.nfcu.net -o J:\software\SSLCert\$Using:dbCertServer\$Using:dbCertServer -d $Using:certPlainPwd -e $Using:certPlainPwd" -Verbose
  }
}
$certFile = Get-ChildItem \\SWVDCLVSNDBDB01\j$\software\SSLCert\$dbCertServer\ | ? {$_.Name -match 'cer'} | ? {$_.Mode -match 'a'}
$pvkFile = Get-ChildItem \\SWVDCLVSNDBDB01\j$\software\SSLCert\$dbCertServer\ | ? {$_.Name -match 'pvk'} | ? {$_.Mode -match 'a'}
Write-Host $certFile',' $pvkFile files have been created/exist -ForegroundColor Green

#Step: Import or overwrite certificate on the server My folder if it does not exist
#$psSession = New-PSSession -ComputerName $dbCertServer -EnableNetworkAccess
#Remove-PSSession -Session $psSession -Verbose

#run ouput of below command on the certificate server

if($dbCertificate -eq $null) {  
   Copy-Item  $pfxFile.FullName -Destination \\$dbCertServer\j$\Temp\ -Verbose  
   Invoke-Command -ComputerName  $dbCertServer -ScriptBlock {  
      Import-PfxCertificate -FilePath "J:\Temp\$pfxFile" -Password $certSecPwd -CertStoreLocation Cert:\LocalMachine\My -Exportable -Verbose 
   }
}

#Step: Get the certificate from the local server
$newCert = Get-ChildItem Cert:\LocalMachine\My | Select-Object -First 1             

#Step: Check if SQL certificate is already instaleld on the server.
$oldSqlCert = get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\*\MSSQLServer\SuperSocketNetLib" -Name "Certificate"  -Verbose

if($oldSqlCert -ne $null) {
    if($oldSqlCert.Certificate -eq $newCert.Thumbprint) {
       Write-host  CERT: $oldSqlCert.Certificate already exist on SQL Server:$dbCertServer -ForegroundColor Yellow
    }
}
else {
    #Step: Load the certificate on the SQL server
    $certificateObject = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2
    $PfxPath = "\\SWVDCLVSNDBDB01\j$\software\SSLCert\$dbCertServer\$pfxFile"
    $certificateObject.Import($PfxPath, $certSecPwd , [System.Security.Cryptography.X509Certificates.X509KeyStorageFlags]::DefaultKeySet)

    Set-ItemProperty -Path $(get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\*\MSSQLServer\SuperSocketNetLib").PsPath -Name "Certificate" -Type String -Value "$($certificateObject.Thumbprint)" -Verbose

    #Step: Restart SQL Service
    Restart-SQLService -dbServer $dbCertServer

    #Step: Check error log file
    Get-SqlErrorLog  -ServerInstance $dbCertServer  -Since Midnight -Verbose | ? {$_.Text -match 'encryption'}
}

#######################################################
#                 ENABLE TDE                          # 
#######################################################
#Step: Create new Master key, if not already exist
$masterKey = (Invoke-Sqlcmd -ServerInstance $dbCertServer -Query "select * from sys.symmetric_keys" | ? {$_.name -match 'DatabaseMaster'}|Select-Object -Property name).name
if($masterKey -eq $null) {
    $query2 = "
        USE master
        CREATE MASTER KEY ENCRYPTION BY PASSWORD = '$certPlainPwd';
        GO
    "    
    Invoke-Sqlcmd -ServerInstance $dbCertServer -Query $query2 -Verbose
    $masterKey = Invoke-Sqlcmd -ServerInstance $dbCertServer -Query "select * from sys.symmetric_keys" | Select-Object -Property name
    Write-Host New masterKey: $masterKey[0] has been created on $dbCertServer -ForegroundColor Green
}
else {
    Write-Host masterKey: $masterKey is already been found on $dbCertServer -ForegroundColor Yellow
    $query21 = "
        ALTER MASTER KEY REGENERATE WITH ENCRYPTION BY PASSWORD = '$($certPlainPwd)';  
        GO  
    "
    Invoke-Sqlcmd -ServerInstance $dbCertServer -Query $query21 -Verbose
    Write-Host masterKey: $masterKey has been regenerated w/ new password on Server:$dbCertServer -ForegroundColor Green
}

#Step: Create certificate
#Check if the server is part of an AVG group, if yes! then replicate the certificate (TDE only) on other replicas before encrypting any database.
$otherReplica = Get-SQLAvgInfo -dbServer $dbCertServer | ? {$_.Replicas -notmatch $dbCertServer} | Select-Object -Property Replicas
if($otherReplica -ne $null) {
    #import TDE certificate on the other replica node
    $otherReplica | % {        
        Add-SQLTDECertificateOnReplica -dbCertServer ($_.Replicas) -dbReplicaServer $dbCertServer -decryPwd $certPlainPwd
    }
}
else {
    Add-SQLTDECertificate -dbCertServer $dbCertServer -decryPwd $certPlainPwd
}

#get list of user databases
$query4 = "
    select * from sys.sysdatabases
    where name not in ('master','tempdb','model','msdb')
"
$userDBList = (Invoke-Sqlcmd -ServerInstance $dbCertServer -Query $query4  -Verbose 4>&1 | Select-Object -Property name).name

#Step: Encrypt user database
$userDBList | % {
    $query5 = "
        USE $_
        CREATE DATABASE ENCRYPTION KEY
        WITH ALGORITHM = AES_256
        ENCRYPTION BY SERVER CERTIFICATE $($dbCertServer)_TDE;
        GO

        ALTER DATABASE $_
        SET ENCRYPTION ON;
        GO
    "
    Invoke-Sqlcmd -ServerInstance $dbCertServer -Query $query5  -Verbose 4>&1 
}


#Test backup/restore
Backup-RestoreSQLDatabase -dbPrimaryServer SWVDCRVDBADB01 -dbSecondaryServer SWWDCRVDBADB01 -dbName ChitaEnc1 -NoLog -Recover

Backup-TSMSQLDatabase -dbServer SWVDCRVDBADB01 -dbName ChitaEnc1 -stripes 2 -alwaysOn

#20180406120200\00009628
Get-TSMSQLBackupInfo -dbServer SWVDCRVDBADB01 -dbName ChitaEnc1 -alwaysOn

Get-SQLAvgInfo -dbServer SWVDCRVDBADB01

New-DatabaseToAVG -dbPrimaryServer SWVDCRVDBADB01 -dbSecondaryServer SWWDCRVDBADB01 -avgName DBADBAG -dbName ChitaEnc1

Get-TSMSQLBackupInfo -dbServer SWVDCRVDBADB01 -dbName ChitaEnc2 -alwaysOn


Backup-TSMSQLDatabase -dbServer SWVDCRVDBADB01 -dbName ChitaTest2 -stripes 2 -alwaysOn

Get-TSMSQLBackupInfo -dbServer SWVDCRVDBADB01 -dbName ChitaTest2 -alwaysOn







