SELECT MAX(login_time) AS [Last Login Time], login_name [Login], DB_NAME(database_id) [Database], @@SERVERNAME [ServerName]
FROM sys.dm_exec_sessions
Where DB_NAME(database_id) in (<dbList>)
GROUP BY login_name, DB_NAME(database_id)
order by DB_NAME(database_id), Login,[Last Login Time]